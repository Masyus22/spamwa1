pkg install curl
pkg install jq
pip install -r requirements.txt
